var $xxlW = 1441;
var $xlW = 1280;
var $lW = 1024;
var $mW = 800;
var $sW = 580;
var $xxl = $('*[class*="xxl-"]');
var $xl = $('*[class*="xl-"]');
var $l = $('*[class*="l-"]');
var $m = $('*[class*="m-"]');
var $s = $('*[class*="s-"]');
var $xs = $('*[class*="xs-"]');
function xxlWidth()
{
	$xxl.each(function(){
		var first = this.className.match(/xxl-(\d+)/)[1];
		var second = this.className.match(/xxl-(\d+)of(\d+)/)[2];
		var result = (first/second)*100;
		$(this).css({'width' : ''+result+'%'});
	});
}
function xlWidth()
{
	$xxl.css({'width' : '100%'});
	$xl.each(function(){
		var first = this.className.match(/xl-(\d+)/)[1];
		var second = this.className.match(/xl-(\d+)of(\d+)/)[2];
		var result = (first/second)*100;
		$(this).css({'width' : ''+result+'%'});
	});
}
function lWidth()
{
	$xxl.css({'width' : '100%'});
	$xl.css({'width' : '100%'});
	$l.each(function(){
		var first = this.className.match(/l-(\d+)/)[1];
		var second = this.className.match(/l-(\d+)of(\d+)/)[2];
		var result = (first/second)*100;
		$(this).css({'width' : ''+result+'%'});
	});
}
function mWidth()
{
	$xxl.css({'width' : '100%'});
	$xl.css({'width' : '100%'});
	$l.css({'width' : '100%'});
	$m.each(function(){
		var first = this.className.match(/m-(\d+)/)[1];
		var second = this.className.match(/m-(\d+)of(\d+)/)[2];
		var result = (first/second)*100;
		$(this).css({'width' : ''+result+'%'});
	});
}
function sWidth()
{
	$xxl.css({'width' : '100%'});
	$xl.css({'width' : '100%'});
	$l.css({'width' : '100%'});
	$m.css({'width' : '100%'});
	$s.each(function(){
		var first = this.className.match(/s-(\d+)/)[1];
		var second = this.className.match(/s-(\d+)of(\d+)/)[2];
		var result = (first/second)*100;
		$(this).css({'width' : ''+result+'%'});
	});
}
function xsWidth()
{
	$xxl.css({'width' : '100%'});
	$xl.css({'width' : '100%'});
	$l.css({'width' : '100%'});
	$m.css({'width' : '100%'});
	$s.css({'width' : '100%'});
	$xs.each(function(){
		var first = this.className.match(/xs-(\d+)/)[1];
		var second = this.className.match(/xs-(\d+)of(\d+)/)[2];
		var result = (first/second)*100;
		$(this).css({'width' : ''+result+'%'});
	});
}
$(function(){
	if($(window).innerWidth() > $xxlW){
		xsWidth();
		sWidth();
		mWidth();
		lWidth();
		xlWidth();
		xxlWidth();
	} else if($(window).innerWidth() > $xlW){
		xsWidth();
		sWidth();
		mWidth();
		lWidth();
		xlWidth();
	} else if($(window).innerWidth() > $lW){
		xsWidth();
		sWidth();
		mWidth();
		lWidth();
	} else if($(window).innerWidth() > $mW){
		xsWidth();
		sWidth();
		mWidth();
	} else if($(window).innerWidth() > $sW){
		xsWidth();
		sWidth();
	} else{
		xsWidth();
	}
});
$(window).on('load resize', function(){
	if($(window).innerWidth() > $xxlW){
		xsWidth();
		sWidth();
		mWidth();
		lWidth();
		xlWidth();
		xxlWidth();
	} else if($(window).innerWidth() > $xlW){
		xsWidth();
		sWidth();
		mWidth();
		lWidth();
		xlWidth();
	} else if($(window).innerWidth() > $lW){
		xsWidth();
		sWidth();
		mWidth();
		lWidth();
	} else if($(window).innerWidth() > $mW){
		xsWidth();
		sWidth();
		mWidth();
	} else if($(window).innerWidth() > $sW){
		xsWidth();
		sWidth();
	} else{
		xsWidth();
	}
});